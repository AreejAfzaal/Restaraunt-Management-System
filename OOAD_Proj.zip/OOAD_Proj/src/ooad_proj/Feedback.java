/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooad_proj;

/**
 *
 * @author Atom
 */
public class Feedback {
    
    String review;
    String customerName;
    String email;
    String phone;
    int ratings;
    
    Feedback()
    {
        this.review=null;
        this.customerName=null;
        this.ratings=0;
    }
    Feedback(String rev, String name, String email, String phone, int rat)
    {
        this.review=rev;
        this.customerName=name;
        this.email=email;
        this.phone=phone;
        this.ratings=rat;
    }
    void getfeedback()
    {
        System.out.println("Customer Name: " +customerName);
        System.out.println("Email: "+email);
        System.out.println("Phone: "+email);
        System.out.println("Review: " +review); 
        System.out.println("Rating: " +ratings); 
    }
    int getrating() //helper function
    {
        return ratings;
    }
    
}
