/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooad_proj;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * 
 * @author l174205
 */
public class OOAD_Proj {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
        dbConnectivity db=new dbConnectivity();
        
        String CNIC="35111-9555055-9";
        String name="Noyan";
        Restaurant restaurant=new Restaurant(CNIC,name);
        List<Tables> tables=db.PopulateTableList();
        
        List<Employee> employees=db.PopulateEmployeeList();
        restaurant.setEmployees(employees);
        
       
        Menu menu=db.PopulateMenuList();
        restaurant.setMenu(menu);
        
        List<Feedback> feedback=db.PopulateFeedbackList();
        restaurant.setFeedback(feedback);
        
        Kitchen kitchen=new Kitchen();
        restaurant.setTables(tables);
       
        restaurant.setKitchen(kitchen);
        
        MainFrame1 mf;
       
       
        Scanner cin= new Scanner(System.in);
       
  
        System.out.println("WELCOME TO RESTAURANT MANAGEMENT SYSTEM");
        System.out.println("\n\nEnter PIN : ");
        boolean system=true;
        String PIN = cin.nextLine();
        if(!restaurant.loginAdmin(PIN)&&!restaurant.loginEmployee(PIN)){
            System.out.println("YOU ENTERED AN INVALID PIN\nENTER AGAIN.");
            while(restaurant.loginAdmin(PIN)||restaurant.loginEmployee(PIN)){
                //
                
            }
        }
        while(system){
        
        if (restaurant.loginAdmin(PIN))
        {
            boolean AdminSystem=true;
   
            while(AdminSystem){
            System.out.println("Press 1 to add Employee\nPress 2 to view Employees\nPress 3 to view Feedback\nPress 4 to remove Employee\nPress 5 to exit");
            int option=cin.nextInt();
            //  System.out.flush(); 
            switch(option){
                case 1:
                    restaurant.addEmployees();
                    break;
                case 2:
                    restaurant.showEmployees();
                    break;
                case 3:
                    restaurant.viewFeedback();
                    break;
                case 4:
                    restaurant.removeEmployees();
                    break;
                  
                case 5:
                    AdminSystem=false;
                    system=false;
                    break;
            }
                      
            }
        }
        else  if (restaurant.loginEmployee(PIN))
        {
            boolean EmployeeSystem=true;
   
            while(EmployeeSystem){
            System.out.println("Press 1 to view tables\nPress 2 to see Menu\nPress 3 to see tables orders\nPress 4 to add order to a table");
            System.out.println("Press 5 to search table\nPress 6 to Add Feedback\nPress 7 to exit");
            int option=cin.nextInt();
            //  System.out.flush(); 
            switch(option){
                case 1:
                    restaurant.showTables();
                    break;
                case 2:
                    restaurant.getMenu().showMenu();
                    break;
                case 3:
                    restaurant.showTableOrders();
                    break;
                case 4:
                    System.out.println("Enter the Table No to add Order");
                    int tno=cin.nextInt();
                    if(tno==0||tno>restaurant.getTables().size()){
                        System.out.println("No Such Table Exist");
                    }
                    else{
                        restaurant.getTables().get(tno-1).addOrder(menu);
                        restaurant.getKitchen().updateOrdersInKitchen(restaurant.getTables());
                    }
                    break;
                case 5:
                    restaurant.searchTable();
                    restaurant.occupyTable();
                    break;
                case 6:
                    restaurant.AddFeedback();
                    break;
                case 7:
                    EmployeeSystem=false;
                    system=false;
                    break;
                    
            }
                      
            }
       
        
        }
         
            
        
        //restaurant.setFeedback(feedback);
       
    }
    }
}
