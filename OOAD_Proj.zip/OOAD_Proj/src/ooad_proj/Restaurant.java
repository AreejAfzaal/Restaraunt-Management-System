/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooad_proj;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Noyan
 */
public class Restaurant {
    Admin admin;
    List<Employee> employees;
    List<Tables> tables;
    Menu menu;
    List<Feedback> feedback;
    Kitchen kitchen;
    static final String AdminPIN = "1234";
    static final String EmployeePIN = "4567";

    public Restaurant(String CNIC,String name) {
        admin=Admin.getInstance(CNIC, name);
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }
    
    
    public Admin getAdmin() {
        return admin;
    }
    public Kitchen getKitchen() {
        return kitchen;
    }
    
    public void setKitchen(Kitchen kitchen) {
        this.kitchen = kitchen;
    }
    
    public void setTables(List<Tables> tables) {
        this.tables = tables;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }

    public void setFeedback(List<Feedback> feedback) {
        this.feedback = feedback;
    }
    
    boolean loginAdmin(String str)
    {
        if (str.equals(AdminPIN))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    boolean loginEmployee(String str) {
        if (str.equals(EmployeePIN))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public List<Tables> getTables() {
        return tables;
    }

    public Menu getMenu() {
        return menu;
    }

    public List<Feedback> getFeedback() {
        return feedback;
    }
    void showTables(){
        for(int i=0;i<tables.size();i++)
            tables.get(i).printTable();
    }
    
    void showTableOrders(){
        for(int i=0;i<kitchen.getOrders().size();i++)
            kitchen.getOrders().get(i).printTableOrder();
    }
    
    void occupyTable(){
        Scanner cin = new Scanner(System.in);
        System.out.println("Enter Table No to occupy");
        int tno=cin.nextInt();
        tables.get(tno-1).changeStatus();
    }
    
    void searchTable(){
        Scanner cin = new Scanner(System.in);
        System.out.println("Enter number of persons");
        int tno=cin.nextInt();
        for(int i=tno;i<tables.size();i++){
            for(int j=0;j<tables.size();j++){
                if(tables.get(j).noOfSeats==i&&tables.get(j).statusFree){
                    tables.get(j).printTable();
                }
            }
        }
    }
    
    void showEmployees(){
        System.out.println("\nOwner of the restaurant is: "+admin.getName());
        System.out.println("\nEmployees of the restaurant are:");
        System.out.println(employees.get(0).name);
        System.out.println("Name\t\tcnic\t\t\tPosition\tHireDate\t\tSalary");
        for(int i=0;i<employees.size();i++){
            if(employees.get(i).getClass()==Manager.class){
                System.out.println(employees.get(i).name+"\t\t"+employees.get(i).CNIC+"\t\tManager\t\t"+employees.get(i).hireDate+"\t\t"+(employees.get(i).getSalary()));
            }
            else if(employees.get(i).getClass()==Chef.class){
                System.out.println(employees.get(i).name+"\t\t"+employees.get(i).CNIC+"\t\tChef\t\t"+employees.get(i).hireDate+"\t\t"+employees.get(i).getSalary());
            }
            else if(employees.get(i).getClass()==Waiter.class){
                System.out.println(employees.get(i).name+"\t\t"+employees.get(i).CNIC+"\t\tWaiter\t\t"+employees.get(i).hireDate+"\t\t"+employees.get(i).getSalary());
            }
        }
        System.out.println();
        
    }
    
    void addEmployees() {
       dbConnectivity db=new dbConnectivity();
        Scanner cin = new Scanner(System.in);
        String str,cnic,name;
        float salary;
        System.out.println("\n\nRe-enter PIN to confirm: ");
        str = cin.nextLine();
        if (str.equals(AdminPIN))
        {
            Employee emp;
            System.out.println("\nEnter the type of Employee: ");
            str=cin.nextLine();
            System.out.println("\n\nAdding a new Employee:\nEnter the CNIC: ");
            cnic = cin.nextLine();
            System.out.println("\nEnter the name: ");
            name = cin.nextLine();
            System.out.println("\nEnter the salary: ");
            salary=cin.nextFloat();
            long millis=System.currentTimeMillis();  
            java.sql.Date date=new java.sql.Date(millis);    
            if (str.equalsIgnoreCase("Chef"))
            {
                emp=new Chef(date,salary,cnic,name);
                employees.add(emp);
                db.AddEmployee(emp, str, date);
            }
            if (str.equalsIgnoreCase("Manager"))
            {
                emp=new Manager(date,salary,cnic,name);
                employees.add(emp);
                db.AddEmployee(emp, str, date);
            }
            if (str.equalsIgnoreCase("Waiter"))
            {
                emp=new Waiter(date,salary,cnic,name);
                employees.add(emp);
                db.AddEmployee(emp, str, date);
            }
            
           
            
        }
    }
    void removeEmployees(){
        dbConnectivity db=new dbConnectivity();
        Scanner cin = new Scanner(System.in);
        String str,cnic,name;
        float salary;
        System.out.println("\n\nRe-enter PIN to confirm: ");
        str = cin.nextLine();
        if (str.equals(AdminPIN))
        {
            Employee emp;
            System.out.println("\nEnter the CNIC of the Employee to delete: ");
            cnic = cin.nextLine();
            long millis=System.currentTimeMillis();  
            java.sql.Date date=new java.sql.Date(millis);    
            
            db.removeEmployee(cnic);
            employees=db.PopulateEmployeeList();
            
           
            
        }
    }
    void viewFeedback() {
        for (int i=0;i<feedback.size();i++)
        {
            feedback.get(i).getfeedback();
            System.out.println();
        }
        
    }
    
    void AddFeedback()  
    {
        Feedback fd;
        System.out.println("Enter your name:");
        String name,phone,email,review;
        int rating;
        Scanner scan=new Scanner(System.in);
        System.out.println("Enter your name:");
        name=scan.nextLine();
        System.out.println("Enter your phone number:");
        phone=scan.nextLine();
        System.out.println("Enter your email:");
        email=scan.nextLine();
        System.out.println("Enter your review:");
        review=scan.nextLine();
        System.out.println("Enter ratings:");
        rating=scan.nextInt();
        fd=new Feedback(review,name,email,phone,rating);
        feedback.add(fd);
        dbConnectivity db=new dbConnectivity();
        db.AddFeedback(fd);
       
       
    }

    
}
