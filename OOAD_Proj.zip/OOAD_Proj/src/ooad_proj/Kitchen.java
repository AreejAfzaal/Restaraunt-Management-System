/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooad_proj;

/**
 *
 * @author Huda Asghar
 */
import java.util.*;

public class Kitchen {
    private final List<Items> specialItems=new ArrayList<>();
    private final List<Tables> orders=new ArrayList<>();
    private final List<Integer> completionTime=new ArrayList<>();

    public void updateOrdersInKitchen(List<Tables> allTables){
        if(allTables!=null){
            orders.clear();
            for(int i=0;i<allTables.size();i++){
                if(allTables.get(i).order!=null){
                    orders.add(allTables.get(i));
                }
            }
            this.updateExpectedTime();
        }
    }
    public List<Items> getSpecialItems() {
        return specialItems;
    }

    public List<Tables> getOrders() {
        return orders;
    }

    public List<Integer> getCompletionTime() {
        return completionTime;
    }
    
    
    
    void updateExpectedTime()
    {
        completionTime.clear();
        for(int i=0;i<orders.size();i++){
            completionTime.add(orders.get(i).order.time);
        }
    }
    
    void generateNotification()
    {
        System.out.println("The order is ready!!");
    }
    
    void DisplayChefSpecial()
    {
        for(int i=0; i<specialItems.size();i++)
        {
            System.out.println(specialItems.get(i));
        }
    }
    
    void DisplayOrder()
    {
        for(int i=0; i<orders.size();i++)
        {
             System.out.println(orders.get(i)+"\t"+completionTime);
        }
    }
   
    
}
