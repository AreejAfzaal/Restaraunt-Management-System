/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooad_proj;

import java.util.List;

/**
 *
 * @author l174205
 */
class Order {
    List<Items> items;
    int time;
    List<Integer> quantity;
    float bill;
    
    Order() {
       
    }
    
    public Order(List<Items> items, List<Integer> quantity) {
        this.items = items;
        this.quantity = quantity;
        this.calculateTime();
        this.calculateBill();
    }

    Order(Order order) {
        if(order!=null){
            this.items = order.items;
            this.quantity = order.quantity;
            this.bill = order.bill;
            this.time = order.time;
        }
    }
    private void calculateTime(){
        int sum=0;
        for(int i=0;i<items.size();i++){
            sum+=items.get(i).expectedTimetoPrepare;
        }
        this.time=sum/items.size();
    }
    private void calculateBill(){
        int total=0;
        for(int i=0;i<items.size();i++){
            total+=items.get(i).price*quantity.get(i);
        }
        this.bill=total;
    }
    
    void printOrder(){
        System.out.println("\t Time: "+time+"\t Bill: "+bill);
        for(int i=0;i<items.size();i++){
            System.out.println("Item: "+items.get(i).name+"\t\t Quantity: "+quantity.get(i));
            
        }
        
    }
}
