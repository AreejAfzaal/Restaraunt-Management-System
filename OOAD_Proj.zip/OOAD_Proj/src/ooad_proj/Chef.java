/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooad_proj;

import java.sql.Date;

/**
 *
 * @author Noyan
 */
public class Chef extends Employee{

    final int chefBonus = 20000;

    public Chef(Date hireDate, float salary, String CNIC, String name) {
        super(hireDate, salary, CNIC, name);
    }   

    public int getChefBonus() {
        return chefBonus;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    public float getSalary() {
        return salary+chefBonus;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    public String getCNIC() {
        return CNIC;
    }

    public void setCNIC(String CNIC) {
        this.CNIC = CNIC;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
}
