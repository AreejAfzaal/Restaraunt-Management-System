/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooad_proj;

import static java.lang.System.in;
import java.util.Scanner;

/**
 *
 * @author Noyan
 */
public class Admin extends Person{
    private static Admin instance=null;
    
    
    private Admin(String CNIC, String name) {
        super(CNIC, name);
    }
    
    public static Admin getInstance(String CNIC, String name){
        if(instance==null){
            instance=new Admin(CNIC,name);
        }
        return instance;
    }

    public String getCNIC() {
        return CNIC;
    }

    public String getName() {
        return name;
    }

}
