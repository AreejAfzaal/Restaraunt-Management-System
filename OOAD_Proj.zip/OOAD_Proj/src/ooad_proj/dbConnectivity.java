/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooad_proj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import java.sql.ResultSet;

import java.util.*;

import java.sql.Date;




/**
 *
 * @author Farwa
 */
public class dbConnectivity 
{
    Connection con;
    Statement stmt;
    
    dbConnectivity() //cons
    {
        try
        {
             String s = "jdbc:sqlserver://localhost:1433;databaseName=Restaurant";
             con=DriverManager.getConnection(s,"sa","12345678");


            stmt = con.createStatement(); 
            
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
   
    List<Employee> PopulateEmployeeList()
    {
        List<Employee> employees=new ArrayList<>();
        Employee e1;
        try
        {
        ResultSet rs=stmt.executeQuery("select * from Employee");
        while(rs.next())
        {
            if(rs.getString("category").equalsIgnoreCase("chef"))
            {
                e1=new Chef(rs.getDate("hireDate"),rs.getInt("salary"),rs.getString("CNIC"),rs.getString("name"));
                employees.add(e1);
                
            }
            if(rs.getString("category").equalsIgnoreCase("manager"))
            {
                e1=new Manager(rs.getDate("hireDate"),rs.getInt("salary"),rs.getString("CNIC"),rs.getString("name"));
                employees.add(e1);
            }
            if(rs.getString("category").equalsIgnoreCase("waiter"))
             {
                e1=new Waiter(rs.getDate("hireDate"),rs.getInt("salary"),rs.getString("CNIC"),rs.getString("name"));
                employees.add(e1);
            }
        }
        }
         catch(Exception e)
        {
            System.out.println(e);
        }
        return employees;
    }
    Menu PopulateMenuList()
    {
        Menu menu=new Menu();
        Items item;
        try
        {
            ResultSet rs=stmt.executeQuery("select * from Menu");
            while (rs.next())
            {
                //Items item= new Items(food.get(i),type.get(i),price.get(i),time.get(i));
                item=new Items(rs.getString("name"),rs.getString("category"),rs.getInt("price"),rs.getInt("expectedTimetoPrepare"));
                menu.addItem(item);
            }
        }
         catch(Exception e)
        {
            System.out.println(e);
        }
        return menu;
    }
    List<Feedback> PopulateFeedbackList()
    {
        List<Feedback> feedback=new ArrayList<>();
        Feedback fd;
        try
        {
            ResultSet rs=stmt.executeQuery("select * from Feedback");
            while (rs.next())
            {
                fd=new Feedback(rs.getString("review"),rs.getString("customerName"),rs.getString("email"),rs.getString("phone"),rs.getInt("rating"));
                feedback.add(fd);
            }
            
        }
         catch(Exception e)
        {
            System.out.println(e);
        }
        return feedback;
    }
    List<Tables> PopulateTableList()
    {
        List<Tables> tables=new ArrayList<>();
        Tables tb;
        try
        {
            ResultSet rs=stmt.executeQuery("select * from Tables");
            while (rs.next())
            {
                tb=new Tables(rs.getInt("tableID"),rs.getInt("noOfSeats"),rs.getBoolean("status"),null);
                tables.add(tb);
            }
        }
         catch(Exception e)
        {
            System.out.println(e);
        }
        return tables;
    }
    void AddEmployee(Employee emp,String category,Date date)
    {
        try
        {
            stmt.executeUpdate("insert into Employee values('"+emp.CNIC+"','"+emp.name+"','"+date+"','"+emp.salary+"','"+category+"')");
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    void removeEmployee(String cnic)
    {
        try
        {
            stmt.executeUpdate("delete from Employee where cnic = '"+cnic+"'");
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
   
    
void AddFeedback(Feedback fd)  
    {
        try
        {
            stmt.executeUpdate("insert into Feedback values('"+fd.review+"','"+fd.customerName+"','"+fd.email+"','"+fd.phone+"','"+fd.ratings+"')");
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }


    
}
