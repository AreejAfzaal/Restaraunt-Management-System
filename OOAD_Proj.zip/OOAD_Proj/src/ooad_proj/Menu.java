/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooad_proj;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Zarar
 */

public class Menu {
    List<Items> food=new ArrayList<>();
    void addItem(Items item)
    {
        food.add(item);
    }
    void showMenu()
    {
        
        List<String> category = new ArrayList<>();
        for(int i=0;i<food.size();i++){
            if(!category.contains(food.get(i).category)){
                //System.out.println(i);
                category.add(food.get(i).category);
            }
        }
        for (int i=0;i<category.size();i++)
        {
            System.out.println(category.get(i)+":");
           for (int j=0;j<food.size();j++)
           {
               if (category.get(i).equals(food.get(j).category))
               {
                   food.get(j).Print();
               }
           }
           System.out.println();
        }
    }
}
