/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooad_proj;

import java.sql.Date;

/**
 *
 * @author Noyan
 */
public class Employee extends Person{
    Date hireDate;
    float salary;

    public Employee(Date hireDate, float salary, String CNIC, String name) {
        super(CNIC, name);
        this.hireDate = hireDate;
        this.salary = salary;
    }
    public float getSalary(){
        return 0;
    }
   
    
}
