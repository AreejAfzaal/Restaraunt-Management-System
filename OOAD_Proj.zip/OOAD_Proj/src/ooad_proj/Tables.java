/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooad_proj;

import java.sql.Time;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author l174205
 */
public class Tables {
    int id;
    int noOfSeats;
    boolean statusFree;
    Order order;

    public Tables(int id, int noOfSeats, boolean status, Order order) {
        this.id = id;
        this.noOfSeats = noOfSeats;
        this.statusFree = status;
        this.order = order;
    }

    Tables() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public void changeStatus(){
        if(statusFree==false){
            statusFree=true;
        }
        else if(statusFree==true){
            statusFree=false;
        }
    }
    
    public void addOrder(Menu menu){
        dbConnectivity db=new dbConnectivity();
        if(statusFree){
            Scanner cin = new Scanner(System.in);
            List<Integer> item=new ArrayList<>();
            List<Integer> quantity=new ArrayList<>();
        
            boolean takingOrder=true;
        
            while(takingOrder){
                menu.showMenu();
                System.out.println("Press 1 to add items\nPress 2 to confirm order");
                int option=cin.nextInt();
                switch(option){
                    case 1:
                        System.out.println("Enter the Item Id: ");
                        int id=cin.nextInt();
                        while(id>menu.food.size()||id<=0){
                            System.out.println("Invalid menu item. Please Enter again.");
                            id=cin.nextInt();
                        }
                        item.add(id);
                        System.out.println("Enter the quantity for Item Id = "+id);
                        int qt=cin.nextInt();
                        quantity.add(qt);
                        break;
                    case 2:
                        takingOrder=false;
                        break;
                    
                }
            }
            List<Items> orderItems=new ArrayList<>();
            for(int i=0;i<item.size();i++){
                for(int j=0;j<menu.food.size();j++){
                    if(item.get(i)==menu.food.get(j).itemId){
                        orderItems.add(menu.food.get(j));
                    }
                }
            }
            order=new Order(orderItems,quantity);
        
        }
        else{
            System.out.println("ERROR: Cannot add order to a table that is not occupied.");
        }
    }
    public void printTable(){
        System.out.print("Table No: "+id+"\t Seats: "+noOfSeats);
        if(statusFree){
            System.out.println("\tfree");
        }
        else{
            System.out.println("\toccupied");
        }
    }
    public void printTableOrder(){
        if(order !=null){
            System.out.print("Table No: "+id+"'s Order:\n");
            order.printOrder();
            System.out.println();
        }
    }
}
