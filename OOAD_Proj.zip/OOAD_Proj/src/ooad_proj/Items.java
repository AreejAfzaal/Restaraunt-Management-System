/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ooad_proj;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author Zarar
 */
public class Items {
    private static final AtomicInteger count = new AtomicInteger(0);
    int itemId;
    String name;
    String category;
    int price;
    int expectedTimetoPrepare;
    public Items(String name, String category, int price, int expectedTimetoPrepare) {
        this.itemId=count.incrementAndGet(); 
        this.name = name;
        this.category = category;
        this.price = price;
        this.expectedTimetoPrepare = expectedTimetoPrepare;
    }
    void Print()
    {
        System.out.println(itemId+"\t"+name+"\t\t\tRs."+price);
    }

    
    
}
